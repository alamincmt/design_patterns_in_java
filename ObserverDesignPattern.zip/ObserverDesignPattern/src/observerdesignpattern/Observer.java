/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerdesignpattern;

/**
 *
 * @author itsmd
 */
public interface Observer {
    // method to update observer, used by subject
    public void update();
    
    // attach with subjects to attach
    public void setSubject(Subject subject);
}
