/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strategrydesignpattern;

/**
 *
 * @author itsmd
 */
public class StrategryDesignPattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ShoppingCart shoppingCart = new ShoppingCart();
        
        Item item1 = new Item("123456", 500);
        Item item2 = new Item("123456654321", 5000);
        
        shoppingCart.addItem(item1);
        shoppingCart.addItem(item2);
        
        shoppingCart.pay(new PaypalStrategy("alamin.fits@gmail.com", "MyPass"));
        shoppingCart.pay(new CreditCardStrategy("alamin", "12345678900987654", "786757", "12/20/20"));
    }
    
}
