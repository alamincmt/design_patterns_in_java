/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package builderdesignpattern;

/**
 *
 * @author itsmd
 */
public class BuilderDesignPattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Using builder to get the object in a single line of code and 
        //without any inconsistent state or arguments management issues	
        Computer computer = new Computer.ComputerBuilder("500 GB", "8 GB").setGraphicsCardEnabled(true).build();
        System.out.println(computer.getHDD() + " " + computer.getRAM() + "Bluetooth " + computer.isBluetoothEnabled() + " Graphics Card Enabled: " + computer.isGraphicsCardEnabled());
    }
    
}
