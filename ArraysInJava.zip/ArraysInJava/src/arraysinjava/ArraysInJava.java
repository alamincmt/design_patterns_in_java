/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraysinjava;

import java.util.Scanner;

/**
 *
 * @author Md. Al-Amin
 */
public class ArraysInJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
//        
//        int howmany = scan.nextInt();
//        int[] arr = new int[howmany];
//        for(int i=0; i<arr.length; i++){
//            arr[i] = scan.nextInt();
//        }
//        int[] arr = {12,24,24,42,42};
//        System.out.println("The summation of Array is: "+ sumAnArray(arr));

//        int[][] twoArray = new int[3][3];
//        
//        for(int i=0; i<twoArray.length; i++){
//            for(int j=0; j<twoArray.length; j++){
//            twoArray[i][j] = scan.nextInt();            
//            }
//        }
//        for(int i=0; i<twoArray.length; i++){
//            for(int j=0; j<twoArray.length; j++){
//            
//                if(twoArray[i][j] == 60){
//                    System.out.print(twoArray[i][j] + "\t" + "Found at: "+ i+","+j + " index");
//                } 
//                
//            }
//            
//            System.out.println();
//        }

        try{
            int devide = 50/0;
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            System.out.println("heelo world");
        }
        
        System.out.println("hello I can not print anything.");

    }
    
    
    static int sumAnArray(int[] arr) throws Exception{
        int sum = 0;
        for(int i=0; i<arr.length; i++){
            sum += arr[i];
        }
        return sum;
    }
    
}
