/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopclear;

import java.util.Scanner;

/**
 *
 * @author Md. Al-Amin
 */
public class OOpClear extends Dog{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // OOpClear obj = new OOpClear();
        // obj.display("alamin");
        
        // ==================== This block is for try-catch-finally operation=========
//        Scanner sc = new Scanner(System.in);
//        boolean isError = false;
//        System.out.println("input your marks-");
//        String input = sc.nextLine();
//        try{
//           int mark = Integer.parseInt(input);
//        }catch(Exception e){
//            e.printStackTrace();
//            isError = true;
//        }finally{
//            if(isError){
//                System.out.println("Hey cowboy! input valid data.");
//            }else{
//                System.out.println("Your data is valid!");
//            }
//        }
    // ==================== This block is for try-catch-finally operation=========

//    String objString = new String("alamin");
//    System.out.println(objString.toUpperCase());
        Dog dog = new Dog();
        //dog.eat();
        //dog.color = "Black";
//        System.out.println(dog.color+ dog.leg);
        
        dog.setColor("Black");
        System.out.print(dog.getColor());
    } 
}
