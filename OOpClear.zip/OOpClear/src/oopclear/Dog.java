/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopclear;

/**
 *
 * @author Md. Al-Amin
 */
public class Dog {
    private String color = "red";
    public void setColor(String col){
        this.color = col;
    }
    public String getColor(){
        return color;
    }
//    public int leg = 4;
//    public void eat(){
//        System.out.println("Rice, Haddi, Ruti");
//    }
//  public void bark(String mes){
//      System.out.println(mes);
//      System.out.println("Alaminasdfsdf");
//  }  
}
