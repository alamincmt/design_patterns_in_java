/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorydesignpatter;

/**
 *
 * @author itsmd
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class Server extends Computer{
    private String ram;
    private String hard_disk;
    private String cpu;
    
    public Server(String ram, String hard_disk, String cpu) {
        this.ram = ram;
        this.hard_disk = hard_disk;
        this.cpu = cpu;
    }

    @Override
    public String getRam() {
        return this.ram;
    }

    @Override
    public String getHardDisk() {
        return this.hard_disk;
    }

    @Override
    public String getCpu() {
        return this.cpu;
    }
    
}

