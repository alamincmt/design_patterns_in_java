/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorydesignpatter;

/**
 *
 * @author itsmd
 */
public class FactoryDesignPatter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Computer pc = ComputerFactory.getComputer("PC", "4 GB", "256 GB", "2.5 GHz");
        Computer server = ComputerFactory.getComputer("Server", "16 GB", "1 TB", "3.5 GHz");
        
        System.out.println("Personal Computer :" + pc);
        System.out.println("Server Computer :" + server);
    }
    
}
