/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorydesignpatter;

/**
 *
 * @author itsmd
 */
public abstract class Computer {
    
    public abstract String getRam();
    public abstract String getHardDisk();
    public abstract String getCpu();
    
    @Override
    public String toString(){
        return "Ram " + this.getRam() + " Hard Disk " + this.getHardDisk() + " CPU " + this.getCpu();
    }
    
}
